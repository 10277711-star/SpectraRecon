# SpectraRecon Design Guidelines

## Design Approach

**Tactical Command Interface Design System** - A specialized HUD interface inspired by military command centers and tactical operations software. This system prioritizes readability in high-stress scenarios, clear information hierarchy, and instant data comprehension over aesthetic flourishes.

**Reference Points**: Military flight HUDs, command center displays (NASA Mission Control), tactical gaming interfaces (Rainbow Six Siege operator screens), professional thermal imaging software (FLIR Tools).

## Core Design Principles

1. **Maximum Contrast for Critical Data** - All information must be instantly readable against varying thermal imagery backgrounds
2. **Persistent Visibility** - UI elements remain legible regardless of underlying video content
3. **Information Density Without Clutter** - Pack substantial data while maintaining scanability
4. **No Distracting Animations** - Movement only for essential feedback (radar sweep, processing indicators)

## Typography System

**Font Families**:
- Primary: 'Rajdhani' (Google Fonts) - Technical, military-inspired, excellent number readability
- Monospace: 'Roboto Mono' - For IDs, coordinates, timestamps, technical data
- Fallback: system-ui for maximum performance

**Type Scale**:
- HUD Headers: text-2xl font-bold tracking-wide uppercase
- Metric Values: text-3xl font-bold (neon green for critical numbers)
- Labels: text-xs uppercase tracking-wider font-semibold
- Body Text: text-sm font-medium
- Technical Data: text-xs font-mono
- Status Messages: text-sm font-medium

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8** (p-2, m-4, gap-6, space-y-8)
- Tight spacing within components: 2-4 units
- Component separation: 6-8 units
- Panel padding: 6 units
- Screen margins: 8 units

**Grid Structure**:
- Main Layout: Two-column split (feed area 65% + control panel 35%)
- Feed Area: Full-height container with absolute-positioned overlays
- Control Panel: Vertical stack of collapsible sections with 6-unit gaps
- Mobile: Single column stack, feed first, controls collapse to bottom drawer

**Responsive Breakpoints**:
- Desktop (lg+): Side-by-side feed and controls
- Tablet (md): Feed full-width, controls as expandable bottom panel
- Mobile: Stacked, controls in slide-up drawer

## Color System

**Foundation**:
- Background Base: Camouflage pattern overlay on #0a0a0a (near-black)
- UI Overlay: bg-black/85 (consistent dark translucent layer over all video content)
- Panel Backgrounds: bg-slate-900/95
- Borders: border-slate-700/50

**Accent System**:
- Primary Accent (Critical Data): #00ff88 (neon green) - used for active targets, live metrics, warnings
- Secondary Accent (Labels): #64748b (slate-500) - used for inactive labels, helper text
- Success: #10b981 (green-500) - connection confirmed, processing active
- Warning: #f59e0b (amber-500) - threshold approaching, attention needed
- Error: #ef4444 (red-500) - connection failed, system error
- Info: #06b6d4 (cyan-500) - detection metadata, technical specs

## Component Library

### Navigation & Header
- **Top Command Bar**: Fixed header with app title, mission timestamp, status indicators (connection, FPS, target count)
- Height: h-16, bg-slate-950/98, border-b border-slate-800
- Layout: Flex row with logo left, metrics center, controls right
- Typography: Title in text-lg uppercase tracking-widest, metrics in text-sm font-mono

### Feed Container
- **Thermal Display Area**: Aspect-locked container (16:9) with layered overlays
- Base layer: video element with object-cover
- Overlay 1: Thermal color map (when active) at mix-blend-screen
- Overlay 2: Detection dots, zones, crosshairs absolutely positioned
- Overlay 3: Corner HUD metrics (timestamp, coordinates, zoom level)

### Detection Overlays
- **Hotspot Markers**: Pulsing dots (w-3 h-3) with connecting lines to ID badges
- Dot: bg-green-400 with animate-pulse-slow, shadow-lg shadow-green-500/50
- ID Badge: bg-black/90 px-2 py-1 rounded text-xs font-mono with border-l-2 border-green-400
- Badge Content: ID number + confidence % + movement icon (if moving)
- Zone Boxes: border-2 border-yellow-400/60 with dashed pattern, fill-yellow-400/5

### Control Panel Sections
- **Section Cards**: bg-slate-900/90 border border-slate-700/50 rounded-lg p-6
- Section Headers: text-sm uppercase tracking-wider text-slate-400 mb-4 flex justify-between
- Collapsible: Chevron icon rotates on expand/collapse
- Sections include: Mode Controls, Detection Settings, Device Status, Active Zones, Logs

### Form Controls
- **Toggle Switches**: Large tactical switches (w-14 h-7) with clear ON/OFF states
  - Active: bg-green-500, inactive: bg-slate-700
- **Sliders**: Thick track (h-2 bg-slate-700) with bright thumb (bg-green-400 shadow-green-500/50)
- **Buttons**: 
  - Primary: bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded font-medium
  - Secondary: border border-slate-600 text-slate-300 hover:bg-slate-800
  - Danger: bg-red-600/20 border border-red-500 text-red-400
- **Input Fields**: bg-slate-950/50 border border-slate-700 focus:border-green-500 text-green-50

### Data Display Components
- **Metrics Grid**: Grid with 2-3 columns, each metric has label above value
  - Label: text-xs uppercase text-slate-500
  - Value: text-2xl font-bold text-green-400 font-mono
- **Logs Table**: Dense row display with alternating subtle backgrounds
  - Header: bg-slate-800 text-xs uppercase sticky top-0
  - Rows: hover:bg-slate-800/50, text-sm font-mono
  - Critical logs: border-l-2 border-yellow-400

### Modal Systems
- **Onboarding Modal**: Full-screen overlay (bg-black/95) with centered content card
  - Card: max-w-4xl bg-slate-900 border border-slate-700 rounded-lg p-8
  - Multi-step wizard with progress dots at top
  - Large visuals showing permission flows and features
- **Device Setup Wizard**: Stepped flow with device icons, connection status, calibration preview
  - Each step: bg-slate-800/50 p-6 rounded-lg with numbered badge
  - Success checkmarks in green-400, pending in slate-500

### Special Components
- **Radar Sweep**: Positioned corner overlay (top-right or bottom-left)
  - Circular container (w-32 h-32) with concentric ring borders
  - Rotating sweep line using Framer Motion (animate-spin 4s linear infinite)
  - Semi-transparent: opacity-40 when inactive
- **Snapshot Preview**: Grid of captured frames with overlay badges
  - Each: w-full aspect-video rounded-lg border border-slate-700 hover:border-green-500
  - Timestamp badge absolute top-2 right-2
- **Export Panel**: Action buttons with icon-text pairs, download progress bars

## Images

**Camouflage Background Pattern**: 
- Subtle tactical camouflage texture as body background
- Low-contrast digital camo pattern in slate-900 to slate-950 tones
- Fixed attachment, covers entire viewport
- Overlaid with dark gradient (bg-gradient-to-br from-slate-950/80 to-slate-900/90)
- Should not interfere with readability—purely atmospheric

**Device Icons**:
- Use line-art icons for FLIR, Seek, Walabot, Intel RealSense devices
- Display in device selection wizard as 4-column grid
- Each: w-16 h-16 grayscale, colored on hover/selection

**No Hero Image**: This is a functional dashboard interface, not a marketing page. Focus remains on the live feed area as the primary visual element.

## Animations

**Minimal Motion Strategy**:
- Radar sweep rotation (continuous, slow)
- Hotspot pulse (subtle, 2s interval)
- Panel slide-in on mount (250ms ease-out, once)
- Detection flash when new hotspot appears (green glow 300ms)
- **NO** scroll animations, parallax, or decorative motion

## Accessibility

- All controls keyboard-navigable with visible focus rings (ring-2 ring-green-400)
- ARIA labels for all icon-only buttons
- Camera permission flow with clear text instructions
- High contrast maintained: minimum 7:1 for critical data
- Screen reader announcements for new detections
- Focus trap in modals with Escape to close