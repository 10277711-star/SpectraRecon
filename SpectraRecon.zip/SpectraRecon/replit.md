# SpectraRecon - Tactical Thermal Surveillance Dashboard

## Overview
SpectraRecon is a web-based tactical thermal surveillance and detection dashboard designed for military and rescue operation demonstrations. The application provides real-time thermal imaging simulation, hotspot detection, motion tracking, and comprehensive reporting capabilities.

## Purpose
A demo-capable tactical interface that simulates thermal imaging, motion/occupant detection, and device integration for military/rescue-style scenarios. Intended as a prototype and demonstration tool for recruiters, stakeholders, and as a baseline for later hardware integration.

## Tech Stack
- **Frontend**: React, TypeScript, Tailwind CSS, Shadcn UI, Framer Motion
- **Canvas Processing**: HTML5 Canvas API for thermal color mapping and image processing
- **Webcam**: react-webcam for live video capture
- **State Management**: React hooks and local state
- **Backend**: Express.js with in-memory storage
- **Data Validation**: Zod schemas

## Project Structure
```
client/
├── src/
│   ├── components/       # React components
│   │   ├── ControlPanel.tsx       # Detection settings and controls
│   │   ├── DeviceSetup.tsx        # Device wizard for simulated hardware
│   │   ├── HUDMetrics.tsx         # Real-time metrics display
│   │   ├── LogsPanel.tsx          # Detection event logs
│   │   ├── OnboardingModal.tsx    # First-run tutorial
│   │   ├── OverlayDots.tsx        # Hotspot visualization overlays
│   │   ├── RadarSweep.tsx         # Animated radar component
│   │   ├── SnapshotsPanel.tsx     # Captured snapshots gallery
│   │   ├── ThermalWebcam.tsx      # Main webcam feed processor
│   │   ├── ZoneOverlay.tsx        # Zone rendering on feed
│   │   └── ZonesTool.tsx          # Zone management interface
│   ├── lib/
│   │   ├── thermalUtils.ts        # Detection algorithms and thermal mapping
│   │   └── exportUtils.ts         # JSON/CSV export utilities
│   ├── pages/
│   │   └── Dashboard.tsx          # Main dashboard page
│   └── index.css                  # Global styles and design tokens
shared/
└── schema.ts                  # Zod schemas for all data models
server/
├── routes.ts                  # API endpoints
└── storage.ts                 # In-memory storage interface
```

## Core Features

### 1. Live & Demo Modes
- **Live Webcam Mode**: Real-time capture via react-webcam with normal/thermal toggle
- **Demo Video Mode**: Pre-recorded thermal-style clips for presentations
- Simulated sensor telemetry endpoints

### 2. Thermal Processing & Detection
- Canvas-based frame processing with configurable downscaling
- Brightness-to-thermal color mapping (false-color palette)
- Grid-based hotspot detection with customizable threshold
- Motion detection via frame differencing
- Hotspot merging and confidence scoring

### 3. Visualization & HUD
- Military command-center inspired interface
- Real-time target overlay with ID badges, confidence %, and motion indicators
- Neon green (#00ff88) accents for critical metrics
- Animated radar sweep component
- Corner HUD with mode, timestamp, and status
- FPS, processing time, and target count metrics

### 4. Zone Monitoring
- User-defined detection zones (rectangular regions)
- Zone-based alert triggering when targets detected
- Visual zone overlays with dashed yellow borders
- Enable/disable individual zones

### 5. Snapshot & Export
- Capture current frame with detection overlay
- PNG image export
- JSON export with hotspot metadata
- CSV export for detection logs
- Snapshot gallery with thumbnails

### 6. Device Integration (Simulated)
- 4-step setup wizard
- Support for FLIR, Seek, Walabot, Intel RealSense, and Generic sensors
- USB, Network, and Simulated connection modes
- Simulated calibration process

### 7. Detection Logs
- Timestamped detection events
- Hotspot position, confidence, intensity tracking
- Motion flag and zone association
- CSV export capability

## Detection Settings
- **Threshold** (0-255): Minimum brightness for hotspot detection
- **Cell Size** (8-64px): Grid cell size for detection
- **Downscale** (80-320px): Processing resolution for performance
- **Motion Threshold** (0-100): Sensitivity for motion detection
- **Merge Distance** (5-50): Distance for combining nearby hotspots

## Design System

### Colors
- **Primary**: #00ff88 (neon green) - critical metrics, active targets
- **Background**: Deep slate with blue undertones (215° hue, 25% saturation)
- **Accents**: Yellow (#f59e0b) for zones/warnings, Amber for motion indicators
- **Text Hierarchy**: White (default), Slate-400 (secondary), Slate-500 (tertiary)

### Typography
- **Primary Font**: Rajdhani (tactical, military-inspired)
- **Monospace**: Roboto Mono (technical data, metrics, IDs)
- **Sizes**: Large metrics (3xl), headers (2xl), body (sm-base), technical (xs)

### Spacing
- Consistent 6-8 unit padding for panels
- 4-6 unit gaps between components
- 2-4 unit spacing within components

### Animations
- Radar sweep: 4s continuous rotation
- Hotspot pulse: 2s breathing animation
- Panel slide-in: 250ms ease-out
- Detection flash: 300ms green glow

## User Workflows

### Quick Start
1. Opens to onboarding modal with tutorial
2. Select Live Feed or Demo Video mode
3. Toggle Normal/Thermal view
4. Adjust detection threshold (default: 128)
5. Click "Start Detection"
6. View real-time hotspot detection with overlays

### Zone Monitoring
1. Navigate to Zones tab
2. Enter zone name
3. Click "Add Zone" (creates centered 50x50% zone)
4. Zone appears on feed with yellow dashed border
5. Alerts trigger when targets enter zone

### Snapshot Capture
1. Ensure detection is running
2. Click "Capture Snapshot" button
3. Snapshot appears in Snapshots tab
4. Click "Export" to download PNG + JSON

### Device Setup
1. Click Settings icon in header
2. Select device type (FLIR, Seek, etc.)
3. Choose connection method (USB/Network/Simulated)
4. Click "Connect Device" (simulates 2s scan)
5. Click "Start Calibration" (simulates 1.5s process)
6. Click "Finish Setup"

## Privacy & Security
- No facial recognition by default
- All processing happens client-side (local only)
- No data uploads to external servers
- Camera permissions requested explicitly
- Clear privacy notices in onboarding

## Performance Targets
- **FPS**: ~10 FPS processing (100ms intervals)
- **Detection Time**: <50ms per frame at 160px downscale
- **Hotspot Capacity**: Efficiently handles 20+ simultaneous targets
- **Memory**: Minimal GC pressure with canvas reuse

## Recent Changes
- 2025-11-03: Initial implementation with all core MVP features
- Added complete schema definitions for all data models
- Implemented thermal detection engine with motion tracking
- Built comprehensive UI with all 11+ components
- Configured tactical design system with neon green accents

## User Preferences
- Tactical/military aesthetic with command-center styling
- Dark mode only (no light mode for this application)
- High contrast for readability in tactical scenarios
- Neon green highlights for critical information
- Camouflage texture as subtle background element

## Architecture Notes
- Frontend-first architecture with minimal backend
- All image processing done client-side via Canvas API
- In-memory storage for demo purposes (no database)
- React hooks for state management
- Zod for runtime type validation
- Export utilities for JSON/CSV generation

## Future Enhancements (Post-MVP)
- TensorFlow.js integration for AI-powered person detection
- WebSocket-based real sensor integration
- Multi-camera support with feed stitching
- Server-side storage and telemetry ingestion
- Authentication and role-based access
- PDF report generation client-side
- LocalStorage for persistent detection history
