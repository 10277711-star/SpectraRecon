import { DetectionSettings } from "@shared/schema";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Play, Pause, Camera, Video } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

interface ControlPanelProps {
  isRunning: boolean;
  isThermalMode: boolean;
  mode: "live" | "demo";
  settings: DetectionSettings;
  onToggleRunning: () => void;
  onToggleThermalMode: () => void;
  onModeChange: (mode: "live" | "demo") => void;
  onSettingsChange: (settings: DetectionSettings) => void;
  onSnapshot: () => void;
}

export function ControlPanel({
  isRunning,
  isThermalMode,
  mode,
  settings,
  onToggleRunning,
  onToggleThermalMode,
  onModeChange,
  onSettingsChange,
  onSnapshot,
}: ControlPanelProps) {
  return (
    <div className="space-y-6">
      {/* Mode Control */}
      <Card data-testid="card-mode-control">
        <CardHeader className="space-y-0 pb-4">
          <CardTitle className="text-sm uppercase tracking-wider text-slate-400">
            Mode Selection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant={mode === "live" ? "default" : "outline"}
              className="w-full"
              onClick={() => onModeChange("live")}
              data-testid="button-mode-live"
            >
              <Camera className="w-4 h-4 mr-2" />
              Live Feed
            </Button>
            <Button
              variant={mode === "demo" ? "default" : "outline"}
              className="w-full"
              onClick={() => onModeChange("demo")}
              data-testid="button-mode-demo"
            >
              <Video className="w-4 h-4 mr-2" />
              Demo Video
            </Button>
          </div>

          <div className="flex items-center justify-between pt-2">
            <Label htmlFor="thermal-mode" className="text-sm font-medium">
              Thermal View
            </Label>
            <Switch
              id="thermal-mode"
              checked={isThermalMode}
              onCheckedChange={onToggleThermalMode}
              data-testid="switch-thermal-mode"
            />
          </div>
        </CardContent>
      </Card>

      {/* Detection Settings */}
      <Card data-testid="card-detection-settings">
        <CardHeader className="space-y-0 pb-4">
          <CardTitle className="text-sm uppercase tracking-wider text-slate-400">
            Detection Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm">Threshold</Label>
              <span className="text-sm font-mono text-primary" data-testid="text-threshold-value">
                {settings.threshold}
              </span>
            </div>
            <Slider
              value={[settings.threshold]}
              onValueChange={([value]) =>
                onSettingsChange({ ...settings, threshold: value })
              }
              min={0}
              max={255}
              step={5}
              data-testid="slider-threshold"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm">Cell Size</Label>
              <span className="text-sm font-mono text-primary" data-testid="text-cellsize-value">
                {settings.cellSize}px
              </span>
            </div>
            <Slider
              value={[settings.cellSize]}
              onValueChange={([value]) =>
                onSettingsChange({ ...settings, cellSize: value })
              }
              min={8}
              max={64}
              step={4}
              data-testid="slider-cellsize"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm">Downscale</Label>
              <span className="text-sm font-mono text-primary" data-testid="text-downscale-value">
                {settings.downscale}px
              </span>
            </div>
            <Slider
              value={[settings.downscale]}
              onValueChange={([value]) =>
                onSettingsChange({ ...settings, downscale: value })
              }
              min={80}
              max={320}
              step={20}
              data-testid="slider-downscale"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label className="text-sm">Motion Threshold</Label>
              <span className="text-sm font-mono text-primary" data-testid="text-motion-value">
                {settings.motionThreshold}
              </span>
            </div>
            <Slider
              value={[settings.motionThreshold]}
              onValueChange={([value]) =>
                onSettingsChange({ ...settings, motionThreshold: value })
              }
              min={0}
              max={100}
              step={5}
              data-testid="slider-motion"
            />
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <Card data-testid="card-actions">
        <CardHeader className="space-y-0 pb-4">
          <CardTitle className="text-sm uppercase tracking-wider text-slate-400">
            Actions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            variant={isRunning ? "destructive" : "default"}
            className="w-full"
            onClick={onToggleRunning}
            data-testid="button-toggle-running"
          >
            {isRunning ? (
              <>
                <Pause className="w-4 h-4 mr-2" />
                Stop Detection
              </>
            ) : (
              <>
                <Play className="w-4 h-4 mr-2" />
                Start Detection
              </>
            )}
          </Button>

          <Button
            variant="outline"
            className="w-full"
            onClick={onSnapshot}
            disabled={!isRunning}
            data-testid="button-snapshot"
          >
            <Camera className="w-4 h-4 mr-2" />
            Capture Snapshot
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
