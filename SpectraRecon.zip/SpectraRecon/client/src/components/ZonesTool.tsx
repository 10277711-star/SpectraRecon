import { useState, useRef } from "react";
import { Zone } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Square } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";

interface ZonesToolProps {
  zones: Zone[];
  onAddZone: (zone: Omit<Zone, "id" | "createdAt">) => void;
  onToggleZone: (zoneId: string) => void;
}

export function ZonesTool({ zones, onAddZone, onToggleZone }: ZonesToolProps) {
  const [zoneName, setZoneName] = useState("");
  const [isDrawing, setIsDrawing] = useState(false);

  const handleQuickAdd = () => {
    if (!zoneName.trim()) return;

    // Add a centered zone as a quick example
    onAddZone({
      name: zoneName,
      x: 25,
      y: 25,
      width: 50,
      height: 50,
      enabled: true,
    });

    setZoneName("");
  };

  return (
    <Card data-testid="card-zones">
      <CardHeader className="space-y-0 pb-4">
        <CardTitle className="text-sm uppercase tracking-wider text-slate-400">
          Detection Zones
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="zone-name" className="text-sm">
            Zone Name
          </Label>
          <div className="flex gap-2">
            <Input
              id="zone-name"
              value={zoneName}
              onChange={(e) => setZoneName(e.target.value)}
              placeholder="e.g., Restricted Area"
              data-testid="input-zone-name"
            />
            <Button
              onClick={handleQuickAdd}
              disabled={!zoneName.trim()}
              data-testid="button-add-zone"
            >
              <Plus className="w-4 h-4 mr-1" />
              Add
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Zones will be created at the center of the feed
          </p>
        </div>

        {zones.length > 0 && (
          <ScrollArea className="h-[200px]">
            <div className="space-y-2">
              {zones.map((zone) => (
                <div
                  key={zone.id}
                  className="bg-slate-900/50 border border-slate-700/50 rounded p-3"
                  data-testid={`zone-item-${zone.id}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Square className="w-4 h-4 text-yellow-400" />
                      <span className="text-sm font-medium">{zone.name}</span>
                    </div>
                    <Switch
                      checked={zone.enabled}
                      onCheckedChange={() => onToggleZone(zone.id)}
                      data-testid={`switch-zone-${zone.id}`}
                    />
                  </div>
                  <div className="mt-2 text-xs text-muted-foreground font-mono">
                    Position: {zone.x.toFixed(0)}, {zone.y.toFixed(0)} | Size: {zone.width.toFixed(0)} × {zone.height.toFixed(0)}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}

        {zones.length === 0 && (
          <div className="text-center py-6 text-muted-foreground text-sm">
            No zones defined yet
          </div>
        )}
      </CardContent>
    </Card>
  );
}
