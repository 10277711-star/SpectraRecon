import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card } from "@/components/ui/card";
import { Check, Loader2, Wifi, Usb } from "lucide-react";
import { motion } from "framer-motion";

interface DeviceSetupProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: (deviceType: string, connectionType: string) => void;
}

type DeviceType = "FLIR" | "Seek" | "Walabot" | "Intel RealSense" | "Generic";
type ConnectionType = "USB" | "Network" | "Simulated";

export function DeviceSetup({ isOpen, onClose, onComplete }: DeviceSetupProps) {
  const [step, setStep] = useState(1);
  const [deviceType, setDeviceType] = useState<DeviceType>("FLIR");
  const [connectionType, setConnectionType] = useState<ConnectionType>("Simulated");
  const [ipAddress, setIpAddress] = useState("192.168.1.100");
  const [port, setPort] = useState("8080");
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [isCalibrated, setIsCalibrated] = useState(false);

  const deviceOptions: Array<{ value: DeviceType; label: string; description: string }> = [
    { value: "FLIR", label: "FLIR Thermal", description: "Professional thermal imaging cameras" },
    { value: "Seek", label: "Seek Thermal", description: "Compact thermal sensors" },
    { value: "Walabot", label: "Walabot", description: "RF-based 3D imaging sensor" },
    { value: "Intel RealSense", label: "Intel RealSense", description: "Depth sensing cameras" },
    { value: "Generic", label: "Generic Sensor", description: "Custom thermal sensor" },
  ];

  const handleConnect = async () => {
    setIsConnecting(true);
    // Simulate connection delay
    await new Promise((resolve) => setTimeout(resolve, 2000));
    setIsConnecting(false);
    setIsConnected(true);
  };

  const handleCalibrate = async () => {
    setIsCalibrating(true);
    await new Promise((resolve) => setTimeout(resolve, 1500));
    setIsCalibrating(false);
    setIsCalibrated(true);
  };

  const handleFinish = () => {
    onComplete(deviceType, connectionType);
    onClose();
    // Reset state
    setStep(1);
    setIsConnected(false);
    setIsCalibrated(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl" data-testid="dialog-device-setup" aria-describedby="device-setup-description">
        <DialogHeader>
          <DialogTitle className="text-xl uppercase tracking-wide">
            Device Setup Wizard
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6" id="device-setup-description">
          {/* Progress indicators */}
          <div className="flex items-center justify-center gap-2">
            {[1, 2, 3, 4].map((s) => (
              <div
                key={s}
                className={`w-2 h-2 rounded-full ${
                  s <= step ? "bg-primary" : "bg-slate-700"
                }`}
              />
            ))}
          </div>

          {/* Step 1: Select Device Type */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div>
                <h3 className="text-lg font-semibold mb-2">Select Device Type</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Choose the thermal imaging device you want to connect
                </p>
              </div>

              <RadioGroup value={deviceType} onValueChange={(v) => setDeviceType(v as DeviceType)}>
                <div className="grid gap-3">
                  {deviceOptions.map((option) => (
                    <Card
                      key={option.value}
                      className={`p-4 cursor-pointer hover:border-primary transition-colors ${
                        deviceType === option.value ? "border-primary bg-primary/5" : ""
                      }`}
                      onClick={() => setDeviceType(option.value)}
                      data-testid={`device-option-${option.value}`}
                    >
                      <div className="flex items-center gap-3">
                        <RadioGroupItem value={option.value} id={option.value} />
                        <div className="flex-1">
                          <Label htmlFor={option.value} className="font-semibold cursor-pointer">
                            {option.label}
                          </Label>
                          <p className="text-xs text-muted-foreground">{option.description}</p>
                        </div>
                      </div>
                    </Card>
                  ))}
                </div>
              </RadioGroup>

              <Button className="w-full" onClick={() => setStep(2)} data-testid="button-next-step1">
                Next
              </Button>
            </motion.div>
          )}

          {/* Step 2: Connection Type */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div>
                <h3 className="text-lg font-semibold mb-2">Connection Method</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  How will the device connect to this system?
                </p>
              </div>

              <RadioGroup
                value={connectionType}
                onValueChange={(v) => setConnectionType(v as ConnectionType)}
              >
                <Card
                  className={`p-4 cursor-pointer hover:border-primary transition-colors ${
                    connectionType === "USB" ? "border-primary bg-primary/5" : ""
                  }`}
                  onClick={() => setConnectionType("USB")}
                  data-testid="connection-option-USB"
                >
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="USB" id="usb" />
                    <Usb className="w-5 h-5 text-primary" />
                    <Label htmlFor="usb" className="flex-1 cursor-pointer">
                      USB Connection
                    </Label>
                  </div>
                </Card>

                <Card
                  className={`p-4 cursor-pointer hover:border-primary transition-colors ${
                    connectionType === "Network" ? "border-primary bg-primary/5" : ""
                  }`}
                  onClick={() => setConnectionType("Network")}
                  data-testid="connection-option-Network"
                >
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="Network" id="network" />
                    <Wifi className="w-5 h-5 text-primary" />
                    <div className="flex-1">
                      <Label htmlFor="network" className="cursor-pointer">
                        Network Connection
                      </Label>
                      {connectionType === "Network" && (
                        <div className="mt-3 space-y-2">
                          <div>
                            <Label className="text-xs">IP Address</Label>
                            <Input
                              value={ipAddress}
                              onChange={(e) => setIpAddress(e.target.value)}
                              placeholder="192.168.1.100"
                              className="mt-1"
                              data-testid="input-ip-address"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">Port</Label>
                            <Input
                              value={port}
                              onChange={(e) => setPort(e.target.value)}
                              placeholder="8080"
                              className="mt-1"
                              data-testid="input-port"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>

                <Card
                  className={`p-4 cursor-pointer hover:border-primary transition-colors ${
                    connectionType === "Simulated" ? "border-primary bg-primary/5" : ""
                  }`}
                  onClick={() => setConnectionType("Simulated")}
                  data-testid="connection-option-Simulated"
                >
                  <div className="flex items-center gap-3">
                    <RadioGroupItem value="Simulated" id="simulated" />
                    <Label htmlFor="simulated" className="flex-1 cursor-pointer">
                      Simulated (Demo Mode)
                    </Label>
                  </div>
                </Card>
              </RadioGroup>

              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setStep(1)} className="flex-1" data-testid="button-back-step2">
                  Back
                </Button>
                <Button onClick={() => setStep(3)} className="flex-1" data-testid="button-next-step2">
                  Next
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Connect */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div>
                <h3 className="text-lg font-semibold mb-2">Establish Connection</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Attempting to connect to {deviceType} via {connectionType}
                </p>
              </div>

              <Card className="p-6 bg-slate-900/50">
                <div className="flex flex-col items-center justify-center py-8">
                  {!isConnected ? (
                    <>
                      {isConnecting ? (
                        <>
                          <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
                          <p className="text-sm text-muted-foreground">
                            Scanning for devices...
                          </p>
                        </>
                      ) : (
                        <>
                          <div className="w-12 h-12 border-2 border-primary rounded-full flex items-center justify-center mb-4">
                            <Wifi className="w-6 h-6 text-primary" />
                          </div>
                          <p className="text-sm text-muted-foreground mb-4">Ready to connect</p>
                          <Button onClick={handleConnect} data-testid="button-connect">
                            Connect Device
                          </Button>
                        </>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="w-12 h-12 bg-primary/20 border-2 border-primary rounded-full flex items-center justify-center mb-4">
                        <Check className="w-6 h-6 text-primary" />
                      </div>
                      <p className="text-primary font-semibold mb-2">Connection Successful</p>
                      <p className="text-xs text-muted-foreground">
                        Device {deviceType} connected via {connectionType}
                      </p>
                    </>
                  )}
                </div>
              </Card>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setStep(2)}
                  disabled={isConnecting}
                  className="flex-1"
                  data-testid="button-back-step3"
                >
                  Back
                </Button>
                <Button
                  onClick={() => setStep(4)}
                  disabled={!isConnected}
                  className="flex-1"
                  data-testid="button-next-step3"
                >
                  Next
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 4: Calibrate */}
          {step === 4 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <div>
                <h3 className="text-lg font-semibold mb-2">Calibrate Sensor</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Calibrate the thermal sensor for optimal detection accuracy
                </p>
              </div>

              <Card className="p-6 bg-slate-900/50">
                <div className="flex flex-col items-center justify-center py-8">
                  {!isCalibrated ? (
                    <>
                      {isCalibrating ? (
                        <>
                          <Loader2 className="w-12 h-12 text-primary animate-spin mb-4" />
                          <p className="text-sm text-muted-foreground">
                            Calibrating sensor...
                          </p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm text-muted-foreground mb-4 text-center">
                            Point the sensor at a neutral background and click calibrate
                          </p>
                          <Button onClick={handleCalibrate} data-testid="button-calibrate">
                            Start Calibration
                          </Button>
                        </>
                      )}
                    </>
                  ) : (
                    <>
                      <div className="w-12 h-12 bg-primary/20 border-2 border-primary rounded-full flex items-center justify-center mb-4">
                        <Check className="w-6 h-6 text-primary" />
                      </div>
                      <p className="text-primary font-semibold mb-2">Calibration Complete</p>
                      <p className="text-xs text-muted-foreground">
                        Sensor is ready for operation
                      </p>
                    </>
                  )}
                </div>
              </Card>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setStep(3)}
                  disabled={isCalibrating}
                  className="flex-1"
                  data-testid="button-back-step4"
                >
                  Back
                </Button>
                <Button
                  onClick={handleFinish}
                  disabled={!isCalibrated}
                  className="flex-1"
                  data-testid="button-finish"
                >
                  Finish Setup
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
