import { Snapshot } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Trash2, FileJson, FileSpreadsheet } from "lucide-react";
import { exportSnapshot } from "@/lib/exportUtils";
import { ScrollArea } from "@/components/ui/scroll-area";

interface SnapshotsPanelProps {
  snapshots: Snapshot[];
  onDeleteSnapshot: (id: string) => void;
}

export function SnapshotsPanel({ snapshots, onDeleteSnapshot }: SnapshotsPanelProps) {
  return (
    <Card data-testid="card-snapshots">
      <CardHeader className="space-y-0 pb-4">
        <CardTitle className="text-sm uppercase tracking-wider text-slate-400">
          Snapshots ({snapshots.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {snapshots.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No snapshots captured yet
          </div>
        ) : (
          <ScrollArea className="h-[300px]">
            <div className="space-y-4">
              {snapshots.map((snapshot) => (
                <div
                  key={snapshot.id}
                  className="border border-slate-700 rounded-lg overflow-hidden hover:border-primary transition-colors"
                  data-testid={`snapshot-${snapshot.id}`}
                >
                  <div className="relative aspect-video bg-black">
                    <img
                      src={snapshot.imageDataUrl}
                      alt={`Snapshot ${snapshot.id}`}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-2 right-2 bg-black/80 px-2 py-1 rounded text-xs font-mono">
                      <span className="text-primary">
                        {snapshot.hotspots.length} targets
                      </span>
                    </div>
                  </div>
                  <div className="p-3 bg-slate-900/50 space-y-2">
                    <div className="text-xs font-mono text-muted-foreground">
                      {new Date(snapshot.createdAt).toLocaleString()}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        className="flex-1"
                        onClick={() => exportSnapshot(snapshot)}
                        data-testid={`button-export-${snapshot.id}`}
                      >
                        <Download className="w-3 h-3 mr-1" />
                        Export
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onDeleteSnapshot(snapshot.id)}
                        data-testid={`button-delete-${snapshot.id}`}
                      >
                        <Trash2 className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
