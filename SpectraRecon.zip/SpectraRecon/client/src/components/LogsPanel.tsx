import { DetectionLog } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, MoveRight } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { exportDetectionLogsCSV } from "@/lib/exportUtils";

interface LogsPanelProps {
  logs: DetectionLog[];
}

export function LogsPanel({ logs }: LogsPanelProps) {
  return (
    <Card data-testid="card-logs">
      <CardHeader className="space-y-0 pb-4 flex flex-row items-center justify-between gap-2">
        <CardTitle className="text-sm uppercase tracking-wider text-slate-400">
          Detection Logs ({logs.length})
        </CardTitle>
        {logs.length > 0 && (
          <Button
            size="sm"
            variant="outline"
            onClick={() => exportDetectionLogsCSV(logs)}
            data-testid="button-export-logs"
          >
            <Download className="w-3 h-3 mr-1" />
            Export CSV
          </Button>
        )}
      </CardHeader>
      <CardContent>
        {logs.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm">
            No detections logged yet
          </div>
        ) : (
          <ScrollArea className="h-[400px]">
            <div className="space-y-2">
              {logs.slice().reverse().map((log) => (
                <div
                  key={log.id}
                  className="bg-slate-900/50 border border-slate-700/50 rounded p-3 text-xs font-mono hover:bg-slate-800/50 transition-colors"
                  data-testid={`log-${log.id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-primary font-bold">#{log.hotspotId}</span>
                    <span className="text-muted-foreground">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-slate-400">
                    <div>
                      <span className="text-slate-500">Pos:</span>{" "}
                      {log.x.toFixed(1)}, {log.y.toFixed(1)}
                    </div>
                    <div>
                      <span className="text-slate-500">Conf:</span>{" "}
                      <span className="text-primary">
                        {(log.confidence * 100).toFixed(0)}%
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">Int:</span> {log.intensity.toFixed(0)}
                    </div>
                    <div className="flex items-center gap-1">
                      {log.moving && (
                        <>
                          <MoveRight className="w-3 h-3 text-amber-400" />
                          <span className="text-amber-400">Moving</span>
                        </>
                      )}
                    </div>
                  </div>
                  {log.zoneName && (
                    <div className="mt-2 text-yellow-400">
                      <span className="text-slate-500">Zone:</span> {log.zoneName}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
