import { Hotspot } from "@shared/schema";

export interface ThermalColor {
  r: number;
  g: number;
  b: number;
}

// False-color thermal palette (cool to hot)
export const getThermalColor = (brightness: number): ThermalColor => {
  // Normalize brightness 0-255 to 0-1
  const normalized = brightness / 255;
  
  if (normalized < 0.25) {
    // Black to blue
    const t = normalized / 0.25;
    return { r: 0, g: 0, b: Math.floor(255 * t) };
  } else if (normalized < 0.5) {
    // Blue to cyan
    const t = (normalized - 0.25) / 0.25;
    return { r: 0, g: Math.floor(255 * t), b: 255 };
  } else if (normalized < 0.75) {
    // Cyan to yellow
    const t = (normalized - 0.5) / 0.25;
    return { r: Math.floor(255 * t), g: 255, b: Math.floor(255 * (1 - t)) };
  } else {
    // Yellow to red
    const t = (normalized - 0.75) / 0.25;
    return { r: 255, g: Math.floor(255 * (1 - t)), b: 0 };
  }
};

export interface DetectionResult {
  hotspots: Hotspot[];
  averageConfidence: number;
  processingTime: number;
}

export interface DetectionParams {
  threshold: number;
  cellSize: number;
  downscale: number;
  motionThreshold: number;
  mergeDistance: number;
}

let nextHotspotId = 1;
let previousFrameData: ImageData | null = null;

export const detectHotspots = (
  imageData: ImageData,
  params: DetectionParams
): DetectionResult => {
  const startTime = performance.now();
  const { threshold, cellSize, mergeDistance, motionThreshold } = params;
  const { width, height, data } = imageData;
  
  const rawHotspots: Array<{
    x: number;
    y: number;
    intensity: number;
    moving: boolean;
  }> = [];

  // Grid-based brightness analysis
  for (let y = 0; y < height; y += cellSize) {
    for (let x = 0; x < width; x += cellSize) {
      let totalBrightness = 0;
      let cellPixels = 0;
      let motionDiff = 0;

      for (let dy = 0; dy < cellSize && y + dy < height; dy++) {
        for (let dx = 0; dx < cellSize && x + dx < width; dx++) {
          const idx = ((y + dy) * width + (x + dx)) * 4;
          const r = data[idx];
          const g = data[idx + 1];
          const b = data[idx + 2];
          
          // Luminance calculation
          const brightness = 0.299 * r + 0.587 * g + 0.114 * b;
          totalBrightness += brightness;
          cellPixels++;

          // Motion detection
          if (previousFrameData) {
            const prevR = previousFrameData.data[idx];
            const prevG = previousFrameData.data[idx + 1];
            const prevB = previousFrameData.data[idx + 2];
            const prevBrightness = 0.299 * prevR + 0.587 * prevG + 0.114 * prevB;
            motionDiff += Math.abs(brightness - prevBrightness);
          }
        }
      }

      const avgBrightness = totalBrightness / cellPixels;
      const avgMotion = motionDiff / cellPixels;

      if (avgBrightness > threshold) {
        rawHotspots.push({
          x: (x + cellSize / 2) / width * 100,
          y: (y + cellSize / 2) / height * 100,
          intensity: avgBrightness,
          moving: avgMotion > motionThreshold,
        });
      }
    }
  }

  // Store current frame for next motion detection
  previousFrameData = imageData;

  // Merge close hotspots
  const mergedHotspots: Hotspot[] = [];
  const used = new Set<number>();

  for (let i = 0; i < rawHotspots.length; i++) {
    if (used.has(i)) continue;

    const cluster = [rawHotspots[i]];
    used.add(i);

    for (let j = i + 1; j < rawHotspots.length; j++) {
      if (used.has(j)) continue;

      const dist = Math.sqrt(
        Math.pow(rawHotspots[i].x - rawHotspots[j].x, 2) +
        Math.pow(rawHotspots[i].y - rawHotspots[j].y, 2)
      );

      if (dist < mergeDistance) {
        cluster.push(rawHotspots[j]);
        used.add(j);
      }
    }

    // Average cluster position
    const avgX = cluster.reduce((sum, h) => sum + h.x, 0) / cluster.length;
    const avgY = cluster.reduce((sum, h) => sum + h.y, 0) / cluster.length;
    const avgIntensity = cluster.reduce((sum, h) => sum + h.intensity, 0) / cluster.length;
    const hasMoving = cluster.some(h => h.moving);

    const confidence = Math.min(1, (avgIntensity - threshold) / (255 - threshold));

    mergedHotspots.push({
      id: nextHotspotId++,
      x: avgX,
      y: avgY,
      confidence,
      intensity: avgIntensity,
      moving: hasMoving,
      timestamp: new Date().toISOString(),
    });
  }

  const avgConfidence = mergedHotspots.length > 0
    ? mergedHotspots.reduce((sum, h) => sum + h.confidence, 0) / mergedHotspots.length
    : 0;

  const processingTime = performance.now() - startTime;

  return { hotspots: mergedHotspots, averageConfidence: avgConfidence, processingTime };
};

export const resetMotionDetection = () => {
  previousFrameData = null;
};

export const applyThermalColorMap = (
  sourceCanvas: HTMLCanvasElement,
  destCanvas: HTMLCanvasElement
): void => {
  const sourceCtx = sourceCanvas.getContext("2d", { willReadFrequently: true });
  const destCtx = destCanvas.getContext("2d", { willReadFrequently: true });
  
  if (!sourceCtx || !destCtx) return;

  const imageData = sourceCtx.getImageData(0, 0, sourceCanvas.width, sourceCanvas.height);
  const { data, width, height } = imageData;

  for (let i = 0; i < data.length; i += 4) {
    const brightness = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
    const color = getThermalColor(brightness);
    
    data[i] = color.r;
    data[i + 1] = color.g;
    data[i + 2] = color.b;
    // Keep alpha unchanged
  }

  destCtx.putImageData(imageData, 0, 0);
};
