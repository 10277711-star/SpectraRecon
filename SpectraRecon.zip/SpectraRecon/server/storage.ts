import {
  type Snapshot,
  type InsertSnapshot,
  type Zone,
  type InsertZone,
  type DetectionLog,
  type InsertDetectionLog,
  type DeviceConfig,
  type InsertDeviceConfig,
  type TelemetryData,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Snapshots
  createSnapshot(snapshot: InsertSnapshot): Promise<Snapshot>;
  getSnapshots(): Promise<Snapshot[]>;
  getSnapshot(id: string): Promise<Snapshot | undefined>;
  deleteSnapshot(id: string): Promise<boolean>;

  // Zones
  createZone(zone: InsertZone): Promise<Zone>;
  getZones(): Promise<Zone[]>;
  getZone(id: string): Promise<Zone | undefined>;
  updateZone(id: string, updates: Partial<Zone>): Promise<Zone | undefined>;
  deleteZone(id: string): Promise<boolean>;

  // Detection Logs
  createDetectionLog(log: InsertDetectionLog): Promise<DetectionLog>;
  getDetectionLogs(limit?: number): Promise<DetectionLog[]>;
  clearDetectionLogs(): Promise<void>;

  // Device Configurations
  createDeviceConfig(config: InsertDeviceConfig): Promise<DeviceConfig>;
  getDeviceConfigs(): Promise<DeviceConfig[]>;
  getDeviceConfig(id: string): Promise<DeviceConfig | undefined>;
  updateDeviceConfig(id: string, updates: Partial<DeviceConfig>): Promise<DeviceConfig | undefined>;

  // Telemetry (for simulated sensor data)
  getLatestTelemetry(): Promise<TelemetryData | undefined>;
  storeTelemetry(data: TelemetryData): Promise<void>;
}

export class MemStorage implements IStorage {
  private snapshots: Map<string, Snapshot>;
  private zones: Map<string, Zone>;
  private detectionLogs: DetectionLog[];
  private deviceConfigs: Map<string, DeviceConfig>;
  private latestTelemetry: TelemetryData | undefined;

  constructor() {
    this.snapshots = new Map();
    this.zones = new Map();
    this.detectionLogs = [];
    this.deviceConfigs = new Map();
    this.latestTelemetry = undefined;
  }

  // Snapshots
  async createSnapshot(insertSnapshot: InsertSnapshot): Promise<Snapshot> {
    const id = randomUUID();
    const snapshot: Snapshot = { ...insertSnapshot, id };
    this.snapshots.set(id, snapshot);
    return snapshot;
  }

  async getSnapshots(): Promise<Snapshot[]> {
    return Array.from(this.snapshots.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getSnapshot(id: string): Promise<Snapshot | undefined> {
    return this.snapshots.get(id);
  }

  async deleteSnapshot(id: string): Promise<boolean> {
    return this.snapshots.delete(id);
  }

  // Zones
  async createZone(insertZone: InsertZone): Promise<Zone> {
    const id = randomUUID();
    const zone: Zone = { ...insertZone, id };
    this.zones.set(id, zone);
    return zone;
  }

  async getZones(): Promise<Zone[]> {
    return Array.from(this.zones.values());
  }

  async getZone(id: string): Promise<Zone | undefined> {
    return this.zones.get(id);
  }

  async updateZone(id: string, updates: Partial<Zone>): Promise<Zone | undefined> {
    const zone = this.zones.get(id);
    if (!zone) return undefined;
    const updated = { ...zone, ...updates };
    this.zones.set(id, updated);
    return updated;
  }

  async deleteZone(id: string): Promise<boolean> {
    return this.zones.delete(id);
  }

  // Detection Logs
  async createDetectionLog(insertLog: InsertDetectionLog): Promise<DetectionLog> {
    const id = randomUUID();
    const log: DetectionLog = { ...insertLog, id };
    this.detectionLogs.push(log);
    
    // Keep only the last 1000 logs to prevent memory issues
    if (this.detectionLogs.length > 1000) {
      this.detectionLogs = this.detectionLogs.slice(-1000);
    }
    
    return log;
  }

  async getDetectionLogs(limit?: number): Promise<DetectionLog[]> {
    const logs = [...this.detectionLogs].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    return limit ? logs.slice(0, limit) : logs;
  }

  async clearDetectionLogs(): Promise<void> {
    this.detectionLogs = [];
  }

  // Device Configurations
  async createDeviceConfig(insertConfig: InsertDeviceConfig): Promise<DeviceConfig> {
    const id = randomUUID();
    const config: DeviceConfig = { ...insertConfig, id };
    this.deviceConfigs.set(id, config);
    return config;
  }

  async getDeviceConfigs(): Promise<DeviceConfig[]> {
    return Array.from(this.deviceConfigs.values());
  }

  async getDeviceConfig(id: string): Promise<DeviceConfig | undefined> {
    return this.deviceConfigs.get(id);
  }

  async updateDeviceConfig(
    id: string,
    updates: Partial<DeviceConfig>
  ): Promise<DeviceConfig | undefined> {
    const config = this.deviceConfigs.get(id);
    if (!config) return undefined;
    const updated = { ...config, ...updates };
    this.deviceConfigs.set(id, updated);
    return updated;
  }

  // Telemetry
  async getLatestTelemetry(): Promise<TelemetryData | undefined> {
    return this.latestTelemetry;
  }

  async storeTelemetry(data: TelemetryData): Promise<void> {
    this.latestTelemetry = data;
  }
}

export const storage = new MemStorage();
