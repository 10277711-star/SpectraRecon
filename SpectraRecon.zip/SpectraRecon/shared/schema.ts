import { z } from "zod";

// Hotspot Detection Schema
export const hotspotSchema = z.object({
  id: z.number(),
  x: z.number().min(0).max(100), // percentage 0-100
  y: z.number().min(0).max(100), // percentage 0-100
  confidence: z.number().min(0).max(1),
  intensity: z.number(),
  moving: z.boolean(),
  timestamp: z.string(),
});

export type Hotspot = z.infer<typeof hotspotSchema>;

// Snapshot Schema
export const snapshotSchema = z.object({
  id: z.string(),
  imageDataUrl: z.string(),
  hotspots: z.array(hotspotSchema),
  createdAt: z.string(),
  mode: z.enum(["normal", "thermal"]),
});

export const insertSnapshotSchema = snapshotSchema.omit({ id: true });

export type Snapshot = z.infer<typeof snapshotSchema>;
export type InsertSnapshot = z.infer<typeof insertSnapshotSchema>;

// Zone Schema
export const zoneSchema = z.object({
  id: z.string(),
  name: z.string(),
  x: z.number().min(0).max(100),
  y: z.number().min(0).max(100),
  width: z.number().min(0).max(100),
  height: z.number().min(0).max(100),
  enabled: z.boolean(),
  createdAt: z.string(),
});

export const insertZoneSchema = zoneSchema.omit({ id: true });

export type Zone = z.infer<typeof zoneSchema>;
export type InsertZone = z.infer<typeof insertZoneSchema>;

// Detection Log Schema
export const detectionLogSchema = z.object({
  id: z.string(),
  hotspotId: z.number(),
  x: z.number(),
  y: z.number(),
  confidence: z.number(),
  intensity: z.number(),
  moving: z.boolean(),
  zoneId: z.string().optional(),
  zoneName: z.string().optional(),
  timestamp: z.string(),
});

export const insertDetectionLogSchema = detectionLogSchema.omit({ id: true });

export type DetectionLog = z.infer<typeof detectionLogSchema>;
export type InsertDetectionLog = z.infer<typeof insertDetectionLogSchema>;

// Device Configuration Schema
export const deviceConfigSchema = z.object({
  id: z.string(),
  deviceType: z.enum(["FLIR", "Seek", "Walabot", "Intel RealSense", "Generic"]),
  connectionType: z.enum(["USB", "Network", "Simulated"]),
  ipAddress: z.string().optional(),
  port: z.number().optional(),
  calibrated: z.boolean(),
  connected: z.boolean(),
  lastConnectedAt: z.string().optional(),
  createdAt: z.string(),
});

export const insertDeviceConfigSchema = deviceConfigSchema.omit({ id: true });

export type DeviceConfig = z.infer<typeof deviceConfigSchema>;
export type InsertDeviceConfig = z.infer<typeof insertDeviceConfigSchema>;

// Detection Settings Schema
export const detectionSettingsSchema = z.object({
  threshold: z.number().min(0).max(255).default(128),
  cellSize: z.number().min(8).max(64).default(16),
  downscale: z.number().min(80).max(320).default(160),
  motionThreshold: z.number().min(0).max(100).default(30),
  mergeDistance: z.number().min(5).max(50).default(20),
});

export type DetectionSettings = z.infer<typeof detectionSettingsSchema>;

// Telemetry Data Schema (for simulated sensor feed)
export const telemetryDataSchema = z.object({
  deviceId: z.string(),
  temperature: z.number(),
  humidity: z.number().optional(),
  fps: z.number(),
  processingTime: z.number(),
  hotspotCount: z.number(),
  timestamp: z.string(),
});

export type TelemetryData = z.infer<typeof telemetryDataSchema>;
